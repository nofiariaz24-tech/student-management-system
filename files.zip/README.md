# 🎓 Student Management System

A command-line application built in **Python** to manage student records with full **CRUD** functionality (Create, Read, Update, Delete).

---

## 📌 Features

- ➕ **Add** new students with ID, name, course, grade, and age
- 📋 **View** all students in a formatted table
- 🔍 **Search** students by name or ID
- ✏️ **Update** any student's details
- 🗑️ **Delete** student records with confirmation
- 📊 **Summary** view with grade breakdown chart
- 💾 Data is **saved to a JSON file** so records persist between sessions

---

## 🛠️ Technologies Used

| Technology | Purpose |
|---|---|
| Python 3 | Core programming language |
| JSON | Local data storage |
| os module | File handling |

---

## ▶️ How to Run

Make sure Python 3 is installed on your machine.

```bash
# Clone the repository
git clone https://github.com/your-username/student-management-system.git

# Navigate into the folder
cd student-management-system

# Run the program
python student_management.py
```

---

## 📸 Screenshot

```
=============================================
   STUDENT MANAGEMENT SYSTEM
   Built with Python by Nofia Riaz
=============================================

  MENU
  1. Add New Student
  2. View All Students
  3. Search Student
  4. Update Student
  5. Delete Student
  6. Summary / Stats
  7. Exit

  Enter your choice (1-7):
```

---

## 📂 Project Structure

```
student-management-system/
│
├── student_management.py   # Main application file
├── students.json           # Auto-created when first student is added
└── README.md               # Project documentation
```

---

## 💡 Concepts Applied

- File I/O (reading and writing JSON)
- Functions and modular code structure
- Loops and conditional logic
- Input validation
- Data structures (lists and dictionaries)
- Software Development Lifecycle (SDLC) principles

---

## 👩‍💻 Author

**Nofia Riaz**  
HND Computing Graduate | AI & Software Enthusiast  
📧 nofiariaz24@gmail.com  
🔗 [LinkedIn](https://linkedin.com/in/your-profile)

---

> Built as part of my computing portfolio to demonstrate Python and database management skills.
