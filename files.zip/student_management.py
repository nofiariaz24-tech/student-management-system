# ============================================================
#  STUDENT MANAGEMENT SYSTEM
#  Built with Python | By Nofia Riaz
#  Uses JSON file to store data so records are saved
# ============================================================

import json    # used to save/load student data from a file
import os      # used to check if the data file exists

# ----- File where student records are saved -----
DATA_FILE = "students.json"


# ============================================================
# LOAD & SAVE  (reads/writes the JSON file)
# ============================================================

def load_students():
    """Load all students from the file. If no file exists, return empty list."""
    if os.path.exists(DATA_FILE):
        with open(DATA_FILE, "r") as f:
            return json.load(f)
    return []


def save_students(students):
    """Save the full students list to the file."""
    with open(DATA_FILE, "w") as f:
        json.dump(students, f, indent=4)


# ============================================================
# CORE FUNCTIONS  (add, view, search, update, delete)
# ============================================================

def add_student():
    """Collect student info and add to the list."""
    print("\n--- ADD NEW STUDENT ---")
    name    = input("Enter student name    : ").strip()
    student_id = input("Enter student ID      : ").strip()
    course  = input("Enter course name     : ").strip()
    grade   = input("Enter grade (A/B/C/D) : ").strip().upper()
    age     = input("Enter age             : ").strip()

    # Basic validation — make sure nothing is left empty
    if not name or not student_id or not course:
        print("\n⚠  Name, ID and Course cannot be empty. Student not added.")
        return

    students = load_students()

    # Check if student ID already exists
    for s in students:
        if s["id"] == student_id:
            print(f"\n⚠  A student with ID '{student_id}' already exists!")
            return

    # Build the student record as a dictionary
    student = {
        "id"    : student_id,
        "name"  : name,
        "course": course,
        "grade" : grade,
        "age"   : age
    }

    students.append(student)
    save_students(students)
    print(f"\n✅  Student '{name}' added successfully!")


def view_all_students():
    """Display all students in a formatted table."""
    students = load_students()

    if not students:
        print("\n⚠  No students found. Add some first!")
        return

    print("\n--- ALL STUDENTS ---")
    print(f"{'ID':<12} {'Name':<22} {'Course':<25} {'Grade':<8} {'Age'}")
    print("-" * 75)

    for s in students:
        print(f"{s['id']:<12} {s['name']:<22} {s['course']:<25} {s['grade']:<8} {s['age']}")

    print("-" * 75)
    print(f"Total students: {len(students)}")


def search_student():
    """Search for a student by ID or name."""
    print("\n--- SEARCH STUDENT ---")
    keyword = input("Enter student ID or Name to search: ").strip().lower()

    students = load_students()
    results  = []

    for s in students:
        if keyword in s["id"].lower() or keyword in s["name"].lower():
            results.append(s)

    if not results:
        print(f"\n⚠  No student found matching '{keyword}'.")
        return

    print(f"\n✅  Found {len(results)} result(s):")
    print(f"{'ID':<12} {'Name':<22} {'Course':<25} {'Grade':<8} {'Age'}")
    print("-" * 75)
    for s in results:
        print(f"{s['id']:<12} {s['name']:<22} {s['course']:<25} {s['grade']:<8} {s['age']}")


def update_student():
    """Update an existing student's details by their ID."""
    print("\n--- UPDATE STUDENT ---")
    student_id = input("Enter the Student ID to update: ").strip()

    students = load_students()

    for i, s in enumerate(students):
        if s["id"] == student_id:
            print(f"\nFound: {s['name']} — leave a field blank to keep current value.\n")

            new_name   = input(f"New name    [{s['name']}]   : ").strip()
            new_course = input(f"New course  [{s['course']}] : ").strip()
            new_grade  = input(f"New grade   [{s['grade']}]   : ").strip().upper()
            new_age    = input(f"New age     [{s['age']}]     : ").strip()

            # Only update fields where user typed something
            if new_name:   students[i]["name"]   = new_name
            if new_course: students[i]["course"] = new_course
            if new_grade:  students[i]["grade"]  = new_grade
            if new_age:    students[i]["age"]    = new_age

            save_students(students)
            print(f"\n✅  Student '{students[i]['name']}' updated successfully!")
            return

    print(f"\n⚠  No student found with ID '{student_id}'.")


def delete_student():
    """Remove a student record by ID after confirmation."""
    print("\n--- DELETE STUDENT ---")
    student_id = input("Enter the Student ID to delete: ").strip()

    students = load_students()

    for i, s in enumerate(students):
        if s["id"] == student_id:
            confirm = input(f"\nAre you sure you want to delete '{s['name']}'? (yes/no): ").strip().lower()
            if confirm == "yes":
                students.pop(i)
                save_students(students)
                print(f"\n✅  Student deleted successfully.")
            else:
                print("\n  Deletion cancelled.")
            return

    print(f"\n⚠  No student found with ID '{student_id}'.")


def show_summary():
    """Show a quick stats summary of all students."""
    students = load_students()

    if not students:
        print("\n⚠  No data to summarise yet.")
        return

    total  = len(students)
    grades = {}

    for s in students:
        g = s.get("grade", "N/A")
        grades[g] = grades.get(g, 0) + 1

    print("\n--- SUMMARY ---")
    print(f"  Total Students : {total}")
    print(f"  Grade Breakdown:")
    for grade, count in sorted(grades.items()):
        bar = "█" * count
        print(f"    {grade}  : {bar}  ({count})")


# ============================================================
# MAIN MENU
# ============================================================

def main():
    print("=" * 45)
    print("   STUDENT MANAGEMENT SYSTEM")
    print("   Built with Python by Nofia Riaz")
    print("=" * 45)

    while True:
        print("\n  MENU")
        print("  1. Add New Student")
        print("  2. View All Students")
        print("  3. Search Student")
        print("  4. Update Student")
        print("  5. Delete Student")
        print("  6. Summary / Stats")
        print("  7. Exit")

        choice = input("\n  Enter your choice (1-7): ").strip()

        if   choice == "1": add_student()
        elif choice == "2": view_all_students()
        elif choice == "3": search_student()
        elif choice == "4": update_student()
        elif choice == "5": delete_student()
        elif choice == "6": show_summary()
        elif choice == "7":
            print("\n  Goodbye! 👋\n")
            break
        else:
            print("\n⚠  Invalid choice. Please enter a number between 1 and 7.")


# Entry point — this runs when you type: python student_management.py
if __name__ == "__main__":
    main()
